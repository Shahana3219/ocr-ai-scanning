<div class="container mt-6 text-center">
    <h3>Upload Purchase</h3>
    <p class="text-muted">Click below to upload a purchase invoice and open the OCR review flow.</p>
    <button type="button" class="btn btn-primary btn-lg" onclick="uploadPurchaseWithRef()">
        Upload Purchase
    </button>
</div>

<script>
function uploadPurchaseWithRef() {
    fetch("<?= site_url('generate-reference/109') ?>")
        .then(res => res.json())
        .then(data => {
            let ref = (data.data && data.data.reference) ? data.data.reference : 0;
            window.location.href = "<?= site_url('pocr/pocr') ?>?ref=" + ref;
        })
        .catch(err => {
            console.error('Reference generation failed:', err);
            window.location.href = "<?= site_url('pocr/pocr') ?>";
        });
}
</script>