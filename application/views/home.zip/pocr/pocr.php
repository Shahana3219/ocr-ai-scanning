<?php $prefill = $prefill ?? []; ?>

<!-- =====================================================================
     PAGE-SPECIFIC STYLES (scope under .invoice-page to avoid conflicts)
     ===================================================================== -->
<style>
/* ---- Card section headers ---- */
.inv-section-title {
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: #fff;
  background: linear-gradient(195deg, #42424a, #191919);
  border-radius: 8px 8px 0 0;
  padding: 10px 16px;
  margin: 0;
}
.inv-card {
  border-radius: 0 0 8px 8px;
  border: 1px solid #e9ecef;
  background: #fff;
  padding: 16px 20px 10px;
  margin-bottom: 20px;
}
/* ---- Labels ---- */
.inv-label {
  font-size: 0.75rem;
  font-weight: 600;
  color: #7b809a;
  margin-bottom: 3px;
  display: block;
}
/* ---- Inputs inherit form-control but smaller ---- */
.inv-card .form-control,
.inv-card select.form-control {
  font-size: 0.82rem;
  padding: 6px 10px;
  height: auto;
  margin-bottom: 0;
  border-radius: 6px;
}
/* ---- Totals box ---- */
.totals-table td {
  padding: 5px 10px;
  font-size: 0.83rem;
  border-bottom: 1px solid #f0f0f0;
}
.totals-table tr:last-child td { border-bottom: none; }
.totals-table .tot-label { color: #7b809a; font-weight: 600; width: 55%; }
.totals-table .tot-val   { text-align: right; font-weight: 700; color: #344767; }
.totals-table .grand-row td { background: #f8f9fa; font-size: 0.92rem; }

/* ---- Line-items table ---- */
#itemsTable { font-size: 0.78rem; }
#itemsTable thead th {
  background: linear-gradient(195deg, #42424a, #191919);
  color: #fff;
  font-size: 0.7rem;
  letter-spacing: .06em;
  text-transform: uppercase;
  padding: 8px 6px;
  border: none;
  white-space: nowrap;
}
#itemsTable tbody tr:hover { background: #f8f9ff; }
#itemsTable tbody td {
  padding: 4px 4px;
  vertical-align: middle;
  border-bottom: 1px solid #f0f0f0;
}
#itemsTable tbody td input,
#itemsTable tbody td select {
  font-size: 0.78rem;
  padding: 4px 6px;
  height: auto;
  margin-bottom: 0;
}
.match-list { border: 1px solid #d1d5db; border-radius: 4px; margin-top: 2px; max-height: 140px; overflow-y: auto; }
.match-item  { padding: 5px 8px; font-size: 0.78rem; cursor: pointer; border-bottom: 1px solid #f0f0f0; }
.match-item:last-child { border-bottom: none; }
.match-item:hover  { background: #f3f4f6; }
.match-item.selected { background: #dbeafe; font-weight: 700; }
.match-item.more-link { color: #3b82f6; text-decoration: underline; }
.match-item.disabled  { color: #9ca3af; cursor: default; }

/* ---- Modals ---- */
.inv-modal-overlay {
  display: none;
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  z-index: 1050;
  justify-content: center;
  align-items: center;
  backdrop-filter: blur(2px);
}
.inv-modal-overlay.active {
  display: flex;
}
.inv-modal-box {
  background: #fff;
  border-radius: 12px;
  padding: 24px;
  width: 100%;
  max-width: 600px;
  overflow: visible;
  box-shadow: 0 20px 60px rgba(0,0,0,0.3);
  max-height: 90vh;
  overflow-y: auto;
}
.inv-modal-box.wide { max-width: 900px; }
.inv-modal-hdr { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.inv-modal-hdr h5 { margin: 0; font-weight: 700; font-size: 1rem; color: #344767; }
.inv-modal-close { cursor: pointer; font-size: 1.4rem; color: #7b809a; line-height: 1; background: none; border: none; }
.inv-modal-close:hover { color: #344767; }

/* mini review table inside modal */
table.rev-table { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 0.78rem; }
table.rev-table th { background: #f8f9fa; color: #344767; padding: 6px; font-weight: 700; border: 1px solid #dee2e6; white-space: nowrap; }
table.rev-table td { border: 1px solid #dee2e6; padding: 4px 5px; vertical-align: middle; }

/* ---- OCR Loader ---- */
.ocr-loader-overlay { 
  display:none;
  position:fixed; 
  inset:0; 
  background:rgba(15,23,42,.72); 
  z-index:11000; 
  justify-content:center; 
  align-items:center; 
  backdrop-filter:blur(2px); 
}
.ocr-loader-overlay.active {
  display: flex;
}
.ocr-loader-box { background:rgba(255,255,255,.97); padding:28px 34px; border-radius:16px; max-width:360px; width:100%; text-align:center; box-shadow:0 18px 50px rgba(15,23,42,.22); }
.ocr-loader-spinner { width:52px; height:52px; margin:0 auto 16px; border:5px solid rgba(59,130,246,.18); border-top-color:#2563eb; border-radius:50%; animation:spin 1s linear infinite; }
.ocr-loader-text { font-size:0.95rem; color:#111827; line-height:1.6; margin-bottom:4px; font-weight:600; }
.ocr-loader-subtext { font-size:0.8rem; color:#6b7280; }
@keyframes spin { to { transform:rotate(360deg); } }

/* Flash messages */
.inv-flash { padding: 10px 14px; border-radius: 6px; margin-bottom: 14px; font-size: 0.83rem; }
.inv-flash-success { background: #dcfce7; border: 1px solid #bbf7d0; color: #166534; }
.inv-flash-error   { background: #fee2e2; border: 1px solid #fecaca; color: #991b1b; }

/* Bank details table */
.bank-table td { padding: 6px 10px; font-size: 0.82rem; }
.bank-table td:first-child { color: #7b809a; font-weight: 600; width: 35%; }

/* Info badge */
.inv-badge { display:inline-block; padding: 2px 8px; border-radius: 20px; font-size: 0.7rem; font-weight: 700; }

/* Vendor add modal - specific */
.vendor-form-group { margin-bottom: 12px; }

/* link-style button */
.link-btn { background:none; border:none; color:#3b82f6; font-size:0.75rem; text-decoration:underline; cursor:pointer; padding:0; margin-top:2px; }

/* File Preview Styles */
#filePreviewContainer {
    background: #f8f9fa;
    border-radius: 8px;
    padding: 15px;
    min-height: 300px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px dashed #d1d5db;
}
#filePreviewContent {
    max-width: 100%;
    max-height: 500px;
    overflow: auto;
    text-align: center;
}
#filePreviewImage {
    max-width: 100%;
    max-height: 450px;
    border-radius: 4px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}
.file-detail-item {
    padding: 4px 0;
    font-size: 0.82rem;
    border-bottom: 1px solid #f0f0f0;
}
.file-detail-item:last-child { border-bottom: none; }
.file-detail-item strong { color: #344767; }
</style>

<div class="container-fluid py-2">

  <!-- Flash messages -->
  <?php if($this->session->flashdata('error')): ?>
    <div class="inv-flash inv-flash-error"><?= $this->session->flashdata('error'); ?></div>
  <?php endif; ?>
  <?php if($this->session->flashdata('success')): ?>
    <div class="inv-flash inv-flash-success"><?= $this->session->flashdata('success'); ?></div>
  <?php endif; ?>

<!-- ==========================================================
     OCR UPLOAD MODAL
     ========================================================== -->
<div class="inv-modal-overlay active" id="uploadModal">
  <div class="inv-modal-box">
    <div class="inv-modal-hdr">
      <h5><i class="material-icons-round align-middle" style="font-size:1rem">upload_file</i> Upload Invoice (OCR)</h5>
      <button type="button" class="inv-modal-close" id="btnCloseModal">&times;</button>
    </div>

    <?= form_open_multipart('upload-invoice-ocr', ['id'=>'ocrForm']); ?>
    <div class="mb-3 mt-2">
      <label class="inv-label">Select Invoice File</label>
      <input type="file" name="invoice_file" id="invoice_file" class="form-control"
             accept=".png,.jpg,.jpeg,.pdf" required>
    </div>
    <div class="card bg-light p-3" style="border-radius:8px;font-size:0.78rem;color:#374151;line-height:1.7">
      <strong>How this works:</strong><br>
      • Upload invoice → Preview the file<br>
      • Confirm → System extracts data automatically<br>
      • Review &amp; edit the extracted fields<br>
      • Confirm to fill the form<br><br>
      <strong>Rules:</strong><br>
      • Max file size: <strong>5 MB</strong><br>
      • Formats: PNG, JPG, JPEG, PDF<br>
      • Clear, well-lit images give best results
    </div>
    <div class="d-flex justify-content-end mt-3">
      <button type="button" class="btn btn-info mb-0" id="btnContinueOCR">
        <i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">chevron_right</i>
        Preview File
      </button>
    </div>
    <?= form_close(); ?>
  </div>
</div>

<!-- ==========================================================
     FILE PREVIEW MODAL
     ========================================================== -->
<div class="inv-modal-overlay" id="filePreviewModal">
  <div class="inv-modal-box wide">
    <div class="inv-modal-hdr">
      <h5><i class="material-icons-round align-middle" style="font-size:1rem">image</i> Preview Invoice File</h5>
      <button type="button" class="inv-modal-close" id="btnCloseFilePreview">&times;</button>
    </div>
    
    <div class="row">
      <div class="col-md-8">
        <div id="filePreviewContainer">
          <div id="filePreviewContent">
            <img id="filePreviewImage" src="" alt="Invoice Preview" style="max-width:100%; max-height:450px; display:none;">
            <div id="filePreviewPdf" style="display:none;">
              <i class="material-icons-round" style="font-size:64px; color:#6b7280;">picture_as_pdf</i>
              <p class="mt-2">PDF file selected. Click "Process OCR" to extract data.</p>
            </div>
            <div id="filePreviewPlaceholder" style="color:#9ca3af; padding:60px;">
              <i class="material-icons-round" style="font-size:64px;">upload_file</i>
              <p class="mt-2">No file selected</p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3" style="background:#f8f9fa; border-radius:8px;">
          <h6 style="font-weight:700; color:#344767;">File Details</h6>
          <hr class="my-2">
          <div id="fileDetails">
            <div class="file-detail-item"><strong>Name:</strong> <span id="previewFileName">-</span></div>
            <div class="file-detail-item"><strong>Size:</strong> <span id="previewFileSize">-</span></div>
            <div class="file-detail-item"><strong>Type:</strong> <span id="previewFileType">-</span></div>
          </div>
          <div class="mt-3" style="border-top:1px solid #dee2e6; padding-top:12px;">
            <p style="font-size:0.78rem; color:#6b7280; margin-bottom:0;">
              <i class="material-icons-round" style="font-size:1rem; vertical-align:middle;">info</i>
              Review the file before processing
            </p>
          </div>
        </div>
      </div>
    </div>
    
    <div class="d-flex justify-content-end mt-3" style="gap:8px">
      <button type="button" class="btn btn-outline-secondary btn-sm mb-0" id="btnBackToUpload">← Back to Upload</button>
      <button type="button" class="btn btn-info btn-sm mb-0" id="btnProcessOCR">
        <i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">auto_awesome</i>
        Process OCR
      </button>
    </div>
  </div>
</div>

<!-- ==========================================================
     REVIEW MODAL (edit OCR data)
     ========================================================== -->
<div class="inv-modal-overlay" id="reviewModal">
  <div class="inv-modal-box wide">
    <div class="inv-modal-hdr">
      <h5><i class="material-icons-round align-middle" style="font-size:1rem">rate_review</i> Review Extracted Data</h5>
      <button type="button" class="inv-modal-close" id="btnCloseReview">&times;</button>
    </div>

    <div class="row g-2">
      <div class="col-md-3 col-sm-6">
        <label class="inv-label">Invoice Date</label>
        <input type="date" id="rev_invoice_date" class="form-control">
      </div>
      <div class="col-md-3 col-sm-6">
        <label class="inv-label">Time</label>
        <input type="time" id="rev_invoice_time" class="form-control">
      </div>
      <div class="col-md-3 col-sm-6">
        <label class="inv-label">Due Date</label>
        <input type="date" id="rev_due_date" class="form-control">
      </div>
      <div class="col-md-3 col-sm-6">
        <label class="inv-label">Currency</label>
        <input type="text" id="rev_currency" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Doc No / Order No</label>
        <input type="text" id="rev_order_no" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Reference No</label>
        <input type="text" id="rev_reference_no" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Supplier Invoice No</label>
        <input type="text" id="rev_supplier_invoice_no" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Contract / PO No</label>
        <input type="text" id="rev_contract_po_no" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Contract / PO Date</label>
        <input type="date" id="rev_contract_po_date" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Other Reference No</label>
        <input type="text" id="rev_other_reference_no" class="form-control">
      </div>

      <!-- Customer -->
      <div class="col-md-6">
        <label class="inv-label">Customer</label>
        <input type="text" id="rev_customer_search" class="form-control" placeholder="Search customer..." autocomplete="off">
        <input type="hidden" id="rev_customer_id">
        <div class="match-list" id="rev_customer_matches"></div>
      </div>
      <!-- Vendor -->
      <div class="col-md-6">
        <label class="inv-label">Vendor</label>
        <input type="text" id="rev_vendor_search" class="form-control" placeholder="Search vendor..." autocomplete="off">
        <input type="hidden" id="rev_vendor_id">
        <div class="match-list" id="rev_vendor_matches"></div>
      </div>

      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Customer VAT Reg. No</label>
        <input type="text" id="rev_vat" class="form-control">
      </div>
      <div class="col-md-4 col-sm-6">
        <label class="inv-label">Vendor VAT No</label>
        <input type="text" id="rev_vendor_vat" class="form-control">
      </div>
      <div class="col-md-4">
        <label class="inv-label">Address (Customer)</label>
        <textarea id="rev_address" class="form-control" rows="2"></textarea>
      </div>
      <div class="col-md-4">
        <label class="inv-label">Address (Vendor)</label>
        <textarea id="rev_vendor_address" class="form-control" rows="2"></textarea>
      </div>
    </div>
<input type="hidden" name="reference_no_prefill" id="reference_no_prefill"
       value="<?= isset($prefill_ref) ? html_escape($prefill_ref) : '' ?>">
    <hr class="my-2">
    <label class="inv-label">Line Items</label>
    <div class="table-responsive">
      <table class="rev-table" id="reviewItemsTable">
        <thead>
          <tr>
            <th>Item</th><th>Unit</th><th>Description</th>
            <th>Qty</th><th>Unit Rate</th><th>Discount</th>
            <th>VAT %</th><th>Total</th><th></th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>

    <div class="d-flex justify-content-end mt-3">
      <button type="button" class="btn btn-info mb-0" id="btnGoToPreview">
        Continue to Preview <i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">chevron_right</i>
      </button>
    </div>
  </div>
</div>

<!-- ==========================================================
     PREVIEW MODAL (read-only final check)
     ========================================================== -->
<div class="inv-modal-overlay" id="previewModal">
  <div class="inv-modal-box wide">
    <div class="inv-modal-hdr">
      <h5><i class="material-icons-round align-middle" style="font-size:1rem">preview</i> Preview Invoice Data</h5>
      <span class="inv-modal-close" id="btnClosePreview">&times;</span>
    </div>
    <div class="card bg-light p-3 mb-3" id="previewSummary" style="font-size:0.82rem"></div>
    <div class="table-responsive">
      <table class="rev-table" id="previewItemsTable">
        <thead>
          <tr>
            <th>Item</th><th>Unit</th><th>Description</th>
            <th>Qty</th><th>Unit Rate</th><th>Discount</th>
            <th>VAT %</th><th>Total</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>
    <div class="d-flex justify-content-end mt-3" style="gap:8px">
      <button type="button" class="btn btn-outline-secondary btn-sm mb-0" id="btnBackToReview">← Back to Edit</button>
      <button type="button" class="btn btn-success btn-sm mb-0" id="btnConfirmFillForm">
        <i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">check_circle</i>
        Confirm &amp; Fill Form
      </button>
    </div>
  </div>
</div>

<!-- OCR Loader Overlay -->
<div class="ocr-loader-overlay" id="ocrLoader">
  <div class="ocr-loader-box">
    <div class="ocr-loader-spinner"></div>
    <div class="ocr-loader-text" id="ocrLoaderText">Preparing OCR...</div>
    <div class="ocr-loader-subtext">Please wait while your invoice is uploaded and processed.</div>
  </div>
</div>

<!-- ================================================================
     DATA BRIDGE: PHP → JS
     ================================================================ -->
<script>
  window.ALL_CUSTOMERS = <?= json_encode($customers ?? []) ?>;
  window.ALL_VENDORS   = <?= json_encode($vendors   ?? []) ?>;
  window.ALL_ITEMS     = <?= json_encode($items     ?? []) ?>;
  window.ALL_PROJECTS  = <?= json_encode($projects  ?? []) ?>;
</script>

<!-- ================================================================
     MAIN JS
     ================================================================ -->
<script>
$(function(){

  <?php if (!empty($prefill_ref)): ?>
    $('input[name="reference_no"]').val('<?= html_escape($prefill_ref) ?>');
  <?php endif; ?>

  // -------------------------------------------------------
  // HELPERS
  // -------------------------------------------------------
  function escapeHtml(str){
    return $('<div>').text(str || '').html();
  }

  const DROPDOWN_LIMIT   = 5;
  const MATCH_DISPLAY_LIMIT = 5;

  // -------------------------------------------------------
  // MODAL CONTROLS
  // -------------------------------------------------------
  function showModal(id){ $('#'+id).addClass('active'); }
  function hideModal(id){ $('#'+id).removeClass('active'); }

  $('#btnCloseModal').on('click', function(){ hideModal('uploadModal'); });
  $('#uploadModal').on('click', function(e){ if(e.target===this) hideModal('uploadModal'); });

  $('#btnCloseFilePreview').on('click', function(){ hideModal('filePreviewModal'); showModal('uploadModal'); });
  $('#filePreviewModal').on('click', function(e){ if(e.target===this){ hideModal('filePreviewModal'); showModal('uploadModal'); } });

  $('#btnCloseReview').on('click', function(){ hideModal('reviewModal'); });
  $('#btnClosePreview').on('click', function(){ hideModal('previewModal'); });

  // -------------------------------------------------------
  // OCR LOADER
  // -------------------------------------------------------
  function showOcrLoader(msg){ 
    $('#ocrLoaderText').text(msg||'Processing OCR...'); 
    $('#ocrLoader').addClass('active'); 
  }
  function hideOcrLoader(){ $('#ocrLoader').removeClass('active'); }

  // -------------------------------------------------------
  // DROPDOWN POPULATION
  // -------------------------------------------------------
  function populateLimitedSelect($select, list, $moreLink, limit){
    limit = limit || DROPDOWN_LIMIT;
    list  = list  || [];
    $select.empty().append('<option value="">-- Select --</option>');
    list.slice(0, limit).forEach(function(item){
      $select.append('<option value="'+item.id+'">'+escapeHtml(item.name)+'</option>');
    });
    if(list.length <= limit){
      $moreLink.hide();
    } else {
      $moreLink.show().off('click').on('click', function(e){
        e.preventDefault();
        list.slice(limit).forEach(function(item){
          $select.append('<option value="'+item.id+'">'+escapeHtml(item.name)+'</option>');
        });
        $(this).hide();
      });
    }
  }

  function ensureSelected($select, list, id){
    if(!id) return;
    id = String(id);
    $select.find('option').prop('selected',false);
    let $opt = $select.find('option[value="'+id+'"]');
    if($opt.length === 0){
      const match = (list||[]).find(function(x){ return String(x.id)===id; });
      if(!match) return;
      $select.append('<option value="'+match.id+'">'+escapeHtml(match.name)+'</option>');
      $opt = $select.find('option[value="'+id+'"]');
    }
    $opt.prop('selected',true);
    $select.val(id).trigger('change');
  }

  populateLimitedSelect($('#customer_id'), window.ALL_CUSTOMERS, $('#customerShowMore'));
  populateLimitedSelect($('#vendor_id'),   window.ALL_VENDORS,   $('#vendorShowMore'));

  // -------------------------------------------------------
  // MATCH-LIST
  // -------------------------------------------------------
  function makeMatchRow(item, $container, $hiddenId, $searchInput){
    return $('<div class="match-item"></div>')
      .text(item.name)
      .attr('data-id', item.id)
      .on('click', function(){
        $container.find('.match-item').removeClass('selected');
        $(this).addClass('selected');
        $hiddenId.val(String(item.id)).trigger('change');
        $searchInput.val(item.name);
        const $tr = $hiddenId.closest('tr');
        const $unitSelect = $tr.find('.rev-item-unit');
        if($unitSelect.length){
          const units = item.units || [];
          $unitSelect.html(buildUnitOptions(units));
          if(units.length){
            const base = units.find(u=>u.is_base) || units[0];
            $unitSelect.val(base.unit_id);
            if(base.sales_price) $tr.find('.rev-item-price').val(base.sales_price);
          }
        }
      });
  }

  function renderMatchList($container, $hiddenId, $searchInput, matches, fullList){
    $container.empty();
    fullList = fullList || [];
    const shown = matches.slice(0, MATCH_DISPLAY_LIMIT);
    let stage = matches.length > MATCH_DISPLAY_LIMIT ? 'more_matches' : 'full_list';

    if(matches.length === 0){
      $container.append('<div class="match-item disabled">No close matches found</div>');
    } else {
      shown.forEach(function(item){ $container.append(makeMatchRow(item,$container,$hiddenId,$searchInput)); });
    }

    if(stage === 'full_list' && fullList.length === 0) return;

    const $moreLink = $('<div class="match-item more-link"></div>');
    function updateLabel(){ $moreLink.text(stage==='more_matches'?'Show more matches':'Not the right one? Show all'); }
    updateLabel();

    $moreLink.on('click', function(){
      if(stage==='more_matches'){
        matches.slice(MATCH_DISPLAY_LIMIT).forEach(function(item){
          makeMatchRow(item,$container,$hiddenId,$searchInput).insertBefore($moreLink);
        });
        stage='full_list';
        if(fullList.length===0){ $moreLink.remove(); return; }
        updateLabel();
        return;
      }
      const currentIds = new Set();
      $container.find('.match-item[data-id]').each(function(){ currentIds.add(String($(this).data('id'))); });
      fullList.forEach(function(item){
        if(!currentIds.has(String(item.id))){
          makeMatchRow(item,$container,$hiddenId,$searchInput).insertBefore($moreLink);
        }
      });
      $moreLink.remove();
    });
    $container.append($moreLink);
  }

  function ensureMatchSelected($container, $hiddenId, $searchInput, fullList, id){
    if(!id) return;
    id = String(id);
    const $existing = $container.find('.match-item[data-id="'+id+'"]');
    if($existing.length){
      $container.find('.match-item').removeClass('selected');
      $existing.addClass('selected');
      $hiddenId.val(id);
      $searchInput.val($existing.text());
      return;
    }
    const match = (fullList||[]).find(function(x){ return String(x.id)===id; });
    if(!match) return;
    const $row = makeMatchRow(match,$container,$hiddenId,$searchInput);
    $container.prepend($row);
    $container.find('.match-item').removeClass('selected');
    $row.addClass('selected');
    $hiddenId.val(match.id);
    $searchInput.val(match.name);
  }

  // -------------------------------------------------------
  // LINE ITEMS – unit helpers
  // -------------------------------------------------------
  function buildUnitOptions(units, selectedUnitId){
    units = units || [];
    if(units.length===0) return '<option value="">--</option>';
    let html='';
    units.forEach(function(u){
      const sel = (selectedUnitId && String(selectedUnitId)===String(u.unit_id)) ? ' selected' : '';
      html += '<option value="'+u.unit_id+'"'+sel+'>'+escapeHtml(u.unit_name||u.symbol)+'</option>';
    });
    return html;
  }

  function buildItemOptions(selectedId, fallbackLabel){
    let html='<option value="">-- Select Item --</option>';
    let found=false;
    (window.ALL_ITEMS||[]).forEach(function(item){
      const isSel = String(item.id)===String(selectedId);
      if(isSel) found=true;
      html+='<option value="'+item.id+'"'+(isSel?' selected':'')+'>'+ escapeHtml(item.name)+'</option>';
    });
    if(selectedId && !found){
      html+='<option value="'+selectedId+'" selected>'+escapeHtml(fallbackLabel||'OCR Item')+'</option>';
    }
    return html;
  }

  // -------------------------------------------------------
  // LINE ITEMS – build row HTML
  // -------------------------------------------------------
  var itemRowCounter = 0;
  function buildItemRowHtml(it){
    it = it || {};
    itemRowCounter++;
    const item  = (window.ALL_ITEMS||[]).find(x=>String(x.id)===String(it.item_id||''));
    const units = item ? item.units : [];
    const rowNum = itemRowCounter;
    return '<tr>'+
      '<td style="text-align:center;color:#7b809a">'+rowNum+'</td>'+
      '<td><select name="item_id[]" class="form-control item-select" style="min-width:140px">'+buildItemOptions(it.item_id||'',it.item_label||it.description||'')+'</select></td>'+
      '<td><select name="unit_id[]" class="form-control item-unit" style="min-width:70px">'+buildUnitOptions(units,it.unit_id)+'</select></td>'+
      '<td><input type="text" name="description[]" class="form-control item-description" value="'+escapeHtml(it.description||'')+'" style="min-width:130px"></td>'+
      '<td><input type="number" name="qty[]" class="form-control" value="'+(it.quantity??it.qty??1)+'" style="min-width:55px"></td>'+
      '<td><input type="number" step="0.01" name="unit_price[]" class="form-control" value="'+(it.unit_price??'')+'" style="min-width:75px"></td>'+
      '<td><input type="number" step="0.01" name="discount[]" class="form-control" value="'+(it.discount??0)+'" style="min-width:65px"></td>'+
      '<td><input type="number" step="0.01" name="taxable_amount[]" class="form-control" value="'+(it.taxable_amount??'')+'" readonly style="background:#f9fafb;min-width:80px"></td>'+
      '<td><input type="number" step="0.01" name="vat_rate[]" class="form-control" value="'+(it.vat_rate??15)+'" style="min-width:55px"></td>'+
      '<td><input type="number" step="0.01" name="vat_amount[]" class="form-control" value="'+(it.vat_amount??'')+'" readonly style="background:#f9fafb;min-width:75px"></td>'+
      '<td><input type="number" step="0.01" name="total[]" class="form-control" value="'+(it.total??'')+'" readonly style="background:#f9fafb;min-width:80px"></td>'+
      '<td><button type="button" class="btn btn-sm btn-outline-danger mb-0 btnRemove" title="Remove"><i class="material-icons-round" style="font-size:.85rem">delete</i></button></td>'+
      '</tr>';
  }

  $('#itemsTable tbody').append(buildItemRowHtml({ quantity:1, vat_rate:15 }));

  $(document).on('click', '#addItem', function(e){
    e.preventDefault();
    $('#itemsTable tbody').append(buildItemRowHtml({ quantity:1, vat_rate:15 }));
    recalcTotals();
  });

  $(document).on('click', '.btnRemove', function(){
    $(this).closest('tr').remove();
    renumberRows();
    recalcTotals();
  });

  function renumberRows(){
    $('#itemsTable tbody tr').each(function(i){
      $(this).find('td:first').text(i+1);
    });
    itemRowCounter = $('#itemsTable tbody tr').length;
  }

  // -------------------------------------------------------
  // ROW CALCULATION
  // -------------------------------------------------------
  $(document).on('keyup change', 'input[name="qty[]"], input[name="unit_price[]"], input[name="discount[]"], input[name="vat_rate[]"]', function(){
    const $tr = $(this).closest('tr');
    const qty      = parseFloat($tr.find('input[name="qty[]"]').val())        || 0;
    const price    = parseFloat($tr.find('input[name="unit_price[]"]').val())  || 0;
    const discount = parseFloat($tr.find('input[name="discount[]"]').val())    || 0;
    const vatPct   = parseFloat($tr.find('input[name="vat_rate[]"]').val())    || 0;
    const taxable  = Math.max(0, qty * price - discount);
    const vatAmt   = taxable * vatPct / 100;
    const total    = taxable + vatAmt;
    $tr.find('input[name="taxable_amount[]"]').val(taxable.toFixed(2));
    $tr.find('input[name="vat_amount[]"]').val(vatAmt.toFixed(2));
    $tr.find('input[name="total[]"]').val(total.toFixed(2));
    recalcTotals();
  });

  // -------------------------------------------------------
  // TOTALS RECALCULATION
  // -------------------------------------------------------
  function recalcTotals(){
    let subtotal=0, tax=0, grand=0;
    $('#itemsTable tbody tr').each(function(){
      subtotal += parseFloat($(this).find('input[name="taxable_amount[]"]').val()) || 0;
      tax      += parseFloat($(this).find('input[name="vat_amount[]"]').val())     || 0;
      grand    += parseFloat($(this).find('input[name="total[]"]').val())          || 0;
    });
    const discount = parseFloat($('#discount_amount').val()) || 0;
    const net      = grand - discount;
    $('#tot_subtotal').text(subtotal.toFixed(2));
    $('#tot_tax').text(tax.toFixed(2));
    $('#tot_grand').text(grand.toFixed(2));
    $('#tot_net').text(net.toFixed(2));
    $('#amount_in_words').val(numberToWords(net));
  }

  $('#discount_amount').on('keyup change', recalcTotals);

  function numberToWords(num){
    if(!num || isNaN(num)) return '';
    num = Math.abs(parseFloat(num.toFixed(2)));
    const whole = Math.floor(num);
    const cents  = Math.round((num - whole)*100);
    const ones = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine',
      'Ten','Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen'];
    const tens = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety'];
    function convert(n){
      if(n < 20)   return ones[n];
      if(n < 100)  return tens[Math.floor(n/10)] + (n%10 ? ' '+ones[n%10] : '');
      if(n < 1000) return ones[Math.floor(n/100)]+' Hundred'+(n%100 ? ' '+convert(n%100) : '');
      if(n < 1000000) return convert(Math.floor(n/1000))+' Thousand'+(n%1000 ? ' '+convert(n%1000) : '');
      return convert(Math.floor(n/1000000))+' Million'+(n%1000000 ? ' '+convert(n%1000000) : '');
    }
    let result = (whole > 0 ? convert(whole)+' SAR' : '');
    if(cents > 0) result += (result?' and ':'')+convert(cents)+' Halalas';
    return result ? result+' Only' : 'Zero';
  }

  // -------------------------------------------------------
  // ITEM SELECT
  // -------------------------------------------------------
  $(document).on('change', '.item-select', function(){
    const $tr = $(this).closest('tr');
    const selectedId   = $(this).val();
    const item         = (window.ALL_ITEMS||[]).find(x=>String(x.id)===String(selectedId));
    const selectedText = $(this).find('option:selected').text();
    if(selectedText && selectedText !== '-- Select Item --'){
      $tr.find('.item-description').val(selectedText);
    }
    const units = item ? item.units : [];
    $tr.find('.item-unit').html(buildUnitOptions(units));
    if(units.length){
      const primary = units.find(u=>u.is_base) || units[0];
      $tr.find('.item-unit').val(primary.unit_id);
      if(primary.sales_price) $tr.find('input[name="unit_price[]"]').val(primary.sales_price).trigger('change');
    }
  });

  $(document).on('change', '.item-unit', function(){
    const $tr = $(this).closest('tr');
    const item = (window.ALL_ITEMS||[]).find(x=>String(x.id)===String($tr.find('.item-select').val()));
    const unit = item&&item.units ? item.units.find(u=>String(u.unit_id)===String($(this).val())) : null;
    if(unit && unit.sales_price!=null && unit.sales_price!==''){
      $tr.find('input[name="unit_price[]"]').val(unit.sales_price).trigger('change');
    }
  });

  // -------------------------------------------------------
  // FILE PREVIEW
  // -------------------------------------------------------
  let selectedFile = null;

  $('#btnContinueOCR').on('click', function(){
    const fileInput = $('#invoice_file')[0];
    if(!fileInput.files.length){ alert('Please select a file'); return; }
    const f = fileInput.files[0];
    const ext = (f.name.split('.').pop()||'').toLowerCase();
    if(['png','jpg','jpeg','pdf'].indexOf(ext)===-1){ 
        alert('Invalid file type. Allowed: PNG, JPG, JPEG, PDF'); 
        return; 
    }
    if(f.size > 5 * 1024 * 1024){ 
        alert('File must be below 5MB'); 
        return; 
    }
    
    selectedFile = f;
    showFilePreview(f);
    hideModal('uploadModal');
    showModal('filePreviewModal');
  });

  function showFilePreview(file){
    const reader = new FileReader();
    
    $('#previewFileName').text(file.name);
    $('#previewFileSize').text((file.size / 1024).toFixed(1) + ' KB');
    $('#previewFileType').text(file.type || 'Unknown');
    
    const ext = (file.name.split('.').pop()||'').toLowerCase();
    
    if(ext === 'pdf'){
      $('#filePreviewImage').hide();
      $('#filePreviewPdf').show();
      $('#filePreviewPlaceholder').hide();
    } else if(['png','jpg','jpeg','gif','bmp','webp'].indexOf(ext) !== -1){
      reader.onload = function(e){
        $('#filePreviewImage').attr('src', e.target.result).show();
        $('#filePreviewPdf').hide();
        $('#filePreviewPlaceholder').hide();
      };
      reader.readAsDataURL(file);
    } else {
      $('#filePreviewImage').hide();
      $('#filePreviewPdf').hide();
      $('#filePreviewPlaceholder').show().html(`
        <i class="material-icons-round" style="font-size:64px;">insert_drive_file</i>
        <p class="mt-2">File type: ${ext}</p>
      `);
    }
  }

  $('#btnBackToUpload').on('click', function(){
    hideModal('filePreviewModal');
    showModal('uploadModal');
  });

  // -------------------------------------------------------
  // OCR UPLOAD FLOW
  // -------------------------------------------------------
  function startOcrUpload(file){
    $('#btnProcessOCR').prop('disabled', true).html('<i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">hourglass_top</i> Processing...');
    showOcrLoader('Uploading invoice…');
    
    const formData = new FormData();
    formData.append('invoice_file', file);
    
    $.ajax({
        url: '<?= site_url("upload-invoice-ocr") ?>',
        type: 'POST', 
        data: formData, 
        processData: false, 
        contentType: false, 
        dataType: 'json',
        success: function(res){
            if(res.status === 'success'){
                showOcrLoader('Running OCR on your document…');
                $.ajax({
                    url: '<?= site_url("run-ocr") ?>',
                    type: 'POST', 
                    dataType: 'json',
                    data: { 
                        file_data: res.file_data,
                        file_name: res.file_name,
                        mime_type: res.mime_type
                    },
                    success: function(ocrRes){
                        $('#btnProcessOCR').prop('disabled', false).html('<i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">auto_awesome</i> Process OCR');
                        hideOcrLoader();
                        if(ocrRes.status === 'success'){ 
                            hideModal('filePreviewModal');
                            openReviewModal(ocrRes); 
                        } else { 
                            alert('OCR failed: ' + (ocrRes.message || 'Unknown error')); 
                        }
                    },
                    error: function(xhr){
                        $('#btnProcessOCR').prop('disabled', false).html('<i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">auto_awesome</i> Process OCR');
                        hideOcrLoader();
                        alert('OCR processing failed. HTTP: ' + xhr.status);
                    }
                });
            } else {
                $('#btnProcessOCR').prop('disabled', false).html('<i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">auto_awesome</i> Process OCR');
                hideOcrLoader();
                alert('Upload failed: ' + (res.message || 'Unknown error'));
            }
        },
        error: function(xhr){
            $('#btnProcessOCR').prop('disabled', false).html('<i class="material-icons-round" style="font-size:.9rem;vertical-align:middle">auto_awesome</i> Process OCR');
            hideOcrLoader();
            alert('Server error during upload. HTTP: ' + xhr.status);
        }
    });
  }

  $('#btnProcessOCR').on('click', function(){
    if(!selectedFile){
      alert('No file selected. Please upload a file first.');
      return;
    }
    startOcrUpload(selectedFile);
  });

  $('#ocrForm').on('submit', function(e){ e.preventDefault(); });

  // -------------------------------------------------------
  // REVIEW MODAL
  // -------------------------------------------------------
  let currentOcrRes = null;

  function openReviewModal(ocrRes){
    currentOcrRes = ocrRes;
    const p = ocrRes.prefill || {};

    $('#rev_invoice_date').val(p.invoice_date||'');
    $('#rev_invoice_time').val(p.invoice_time||'');
    $('#rev_due_date').val(p.due_date||'');
    $('#rev_order_no').val(p.order_no||'');
    $('#rev_reference_no').val(p.reference_no||'');
    $('#rev_supplier_invoice_no').val(p.supplier_invoice_number||'');
    $('#rev_contract_po_no').val(p.contract_po_no||p.reference_no||'');
    $('#rev_contract_po_date').val(p.contract_po_date||'');
    $('#rev_other_reference_no').val(p.other_reference_no||'');
    $('#rev_currency').val(p.currency||'');
    $('#rev_vat').val(p.vat||'');
    $('#rev_vendor_vat').val(p.vendor_vat||'');
    $('#rev_address').val(p.customer_address||p.address||'');
    $('#rev_vendor_address').val(p.vendor_address||'');

    const customerMatches = ocrRes.customer_matches || [];
    const vendorMatches   = ocrRes.vendor_matches   || [];
    renderMatchList($('#rev_customer_matches'), $('#rev_customer_id'), $('#rev_customer_search'), customerMatches, window.ALL_CUSTOMERS);
    renderMatchList($('#rev_vendor_matches'),   $('#rev_vendor_id'),   $('#rev_vendor_search'),   vendorMatches,   window.ALL_VENDORS);
    ensureMatchSelected($('#rev_customer_matches'), $('#rev_customer_id'), $('#rev_customer_search'), window.ALL_CUSTOMERS, p.customer_id);
    ensureMatchSelected($('#rev_vendor_matches'),   $('#rev_vendor_id'),   $('#rev_vendor_search'),   window.ALL_VENDORS,   p.vendor_id);

    const items = (ocrRes.parsed && ocrRes.parsed.line_items) || [];
    $('#reviewItemsTable tbody').empty();
    items.forEach(function(it, idx){
      const rowId = 'ritem_'+idx+'_'+Date.now();
      const $row  = $(buildReviewItemRowHtml(it, rowId));
      $('#reviewItemsTable tbody').append($row);
      renderMatchList($row.find('.rev-item-matches'), $row.find('.rev-item-id'), $row.find('.rev-item-search'), it.item_matches||[], window.ALL_ITEMS||[]);
      if(it.item_matches && it.item_matches.length > 0 && !it.item_id){
        ensureMatchSelected($row.find('.rev-item-matches'), $row.find('.rev-item-id'), $row.find('.rev-item-search'), window.ALL_ITEMS||[], it.item_matches[0].id);
        const units = it.item_matches[0].units || [];
        const $unitSelect = $row.find('.rev-item-unit');
        $unitSelect.html(buildUnitOptions(units));
        if(units.length){ const base = units.find(u=>u.is_base)||units[0]; $unitSelect.val(base.unit_id); }
      }
    });

    showModal('reviewModal');
  }

  function buildReviewItemRowHtml(it, rowId){
    it = it || {};
    const item  = (window.ALL_ITEMS||[]).find(x=>String(x.id)===String(it.item_id||''));
    const units = item ? item.units : [];
    return '<tr data-row-id="'+rowId+'">' +
      '<td>'+
        '<input type="hidden" class="rev-item-id" value="'+(it.item_id||'')+'">'+
        '<input type="text" class="form-control rev-item-search" placeholder="Search item..." autocomplete="off" style="font-size:.75rem;padding:3px 6px">'+
        '<div class="match-list rev-item-matches"></div>'+
      '</td>'+
      '<td><select class="form-control rev-item-unit" style="font-size:.75rem;padding:3px 6px">'+buildUnitOptions(units,it.unit_id)+'</select></td>'+
      '<td><input type="text" class="form-control rev-item-desc" value="'+escapeHtml(it.description)+'" style="font-size:.75rem;padding:3px 6px;min-width:110px"></td>'+
      '<td><input type="number" class="form-control rev-item-qty" value="'+(it.quantity??it.qty??1)+'" style="font-size:.75rem;padding:3px 6px;width:55px"></td>'+
      '<td><input type="number" step="0.01" class="form-control rev-item-price" value="'+(it.unit_price??'')+'" style="font-size:.75rem;padding:3px 6px;width:75px"></td>'+
      '<td><input type="number" step="0.01" class="form-control rev-item-discount" value="'+(it.discount??0)+'" style="font-size:.75rem;padding:3px 6px;width:65px"></td>'+
      '<td><input type="number" step="0.01" class="form-control rev-item-vat" value="'+(it.vat_rate??15)+'" style="font-size:.75rem;padding:3px 6px;width:55px"></td>'+
      '<td><input type="number" step="0.01" class="form-control rev-item-total" value="'+(it.total??'')+'" style="font-size:.75rem;padding:3px 6px;width:80px"></td>'+
      '<td><button type="button" class="btn btn-sm btn-outline-danger mb-0 btnRemoveReviewItem" style="padding:2px 6px"><i class="material-icons-round" style="font-size:.8rem">delete</i></button></td>'+
      '</tr>';
  }

  $(document).on('click', '.btnRemoveReviewItem', function(){ $(this).closest('tr').remove(); });

  $(document).on('keyup change', '.rev-item-qty,.rev-item-price,.rev-item-discount,.rev-item-vat', function(){
    const $tr      = $(this).closest('tr');
    const qty      = parseFloat($tr.find('.rev-item-qty').val())      || 0;
    const price    = parseFloat($tr.find('.rev-item-price').val())    || 0;
    const discount = parseFloat($tr.find('.rev-item-discount').val()) || 0;
    const vat      = parseFloat($tr.find('.rev-item-vat').val())      || 0;
    const taxable  = Math.max(0, qty*price - discount);
    $tr.find('.rev-item-total').val((taxable + taxable*vat/100).toFixed(2));
  });

  $(document).on('change', '.rev-item-unit', function(){
    const $tr   = $(this).closest('tr');
    const itemId = $tr.find('.rev-item-id').val();
    const item  = (window.ALL_ITEMS||[]).find(x=>String(x.id)===String(itemId));
    const unit  = item&&item.units ? item.units.find(u=>String(u.unit_id)===String($(this).val())) : null;
    if(unit && unit.sales_price!=null && unit.sales_price!==''){
      $tr.find('.rev-item-price').val(unit.sales_price).trigger('change');
    }
  });

  // -------------------------------------------------------
  // COLLECT REVIEW DATA
  // -------------------------------------------------------
  function collectReviewData(){
    const items = [];
    $('#reviewItemsTable tbody tr').each(function(){
      const $tr       = $(this);
      const itemId    = $tr.find('.rev-item-id').val();
      const unitId    = $tr.find('.rev-item-unit').val();
      const unitLabel = $tr.find('.rev-item-unit option:selected').text();
      const selItem   = itemId ? (window.ALL_ITEMS||[]).find(x=>String(x.id)===String(itemId)) : null;
      items.push({
        description : $tr.find('.rev-item-desc').val(),
        quantity    : $tr.find('.rev-item-qty').val(),
        unit_price  : $tr.find('.rev-item-price').val(),
        discount    : $tr.find('.rev-item-discount').val(),
        vat_rate    : $tr.find('.rev-item-vat').val(),
        total       : $tr.find('.rev-item-total').val(),
        item_id     : itemId || null,
        item_label  : selItem ? selItem.name : $tr.find('.rev-item-desc').val(),
        unit_id     : unitId  || null,
        unit_label  : unitLabel && unitLabel!=='--' ? unitLabel : ''
      });
    });
    return {
      invoice_date          : $('#rev_invoice_date').val(),
      invoice_time          : $('#rev_invoice_time').val(),
      due_date              : $('#rev_due_date').val(),
      order_no              : $('#rev_order_no').val(),
      reference_no          : $('#rev_reference_no').val(),
      supplier_invoice_no   : $('#rev_supplier_invoice_no').val(),
      contract_po_no        : $('#rev_contract_po_no').val(),
      contract_po_date      : $('#rev_contract_po_date').val(),
      other_reference_no    : $('#rev_other_reference_no').val(),
      currency              : $('#rev_currency').val(),
      customer_id           : $('#rev_customer_id').val(),
      customer_text         : $('#rev_customer_search').val(),
      vendor_id             : $('#rev_vendor_id').val(),
      vendor_text           : $('#rev_vendor_search').val(),
      vat                   : $('#rev_vat').val(),
      vendor_vat            : $('#rev_vendor_vat').val(),
      address               : $('#rev_address').val(),
      vendor_address        : $('#rev_vendor_address').val(),
      invoice_no            : (currentOcrRes && currentOcrRes.prefill && currentOcrRes.prefill.invoice_no) || '',
      items                 : items
    };
  }

  // -------------------------------------------------------
  // PREVIEW MODAL
  // -------------------------------------------------------
  let reviewedData = null;

  $('#btnGoToPreview').on('click', function(){
    try {
      reviewedData = collectReviewData();
      if(!reviewedData || !Array.isArray(reviewedData.items)){
        alert('No items or review data available.');
        return;
      }
      $('#previewSummary').html(
        '<div class="row g-2" style="font-size:0.8rem">'+
        '<div class="col-md-4"><strong>Invoice No:</strong> '+escapeHtml(reviewedData.invoice_no)+'</div>'+
        '<div class="col-md-4"><strong>Date:</strong> '+escapeHtml(reviewedData.invoice_date)+'</div>'+
        '<div class="col-md-4"><strong>Due:</strong> '+escapeHtml(reviewedData.due_date)+'</div>'+
        '<div class="col-md-4"><strong>Order No:</strong> '+escapeHtml(reviewedData.order_no)+'</div>'+
        '<div class="col-md-4"><strong>Supplier Inv No:</strong> '+escapeHtml(reviewedData.supplier_invoice_no)+'</div>'+
        '<div class="col-md-4"><strong>Contract/PO:</strong> '+escapeHtml(reviewedData.contract_po_no)+'</div>'+
        '<div class="col-md-4"><strong>Customer:</strong> '+escapeHtml(reviewedData.customer_text)+'</div>'+
        '<div class="col-md-4"><strong>Vendor:</strong> '+escapeHtml(reviewedData.vendor_text)+'</div>'+
        '<div class="col-md-4"><strong>VAT Reg No:</strong> '+escapeHtml(reviewedData.vat)+'</div>'+
        '<div class="col-md-6"><strong>Customer Address:</strong> '+escapeHtml(reviewedData.address)+'</div>'+
        '<div class="col-md-6"><strong>Vendor Address:</strong> '+escapeHtml(reviewedData.vendor_address)+'</div>'+
        '</div>'
      );
      $('#previewItemsTable tbody').empty();
      reviewedData.items.forEach(function(it){
        $('#previewItemsTable tbody').append(
          '<tr><td>'+escapeHtml(it.item_label||it.description||'')+'</td>'+
          '<td>'+escapeHtml(it.unit_label||'')+'</td>'+
          '<td>'+escapeHtml(it.description||'')+'</td>'+
          '<td>'+escapeHtml(String(it.quantity??''))+'</td>'+
          '<td>'+escapeHtml(String(it.unit_price??''))+'</td>'+
          '<td>'+escapeHtml(String(it.discount??0))+'</td>'+
          '<td>'+escapeHtml(String(it.vat_rate??''))+'</td>'+
          '<td>'+escapeHtml(String(it.total??''))+'</td></tr>'
        );
      });
      hideModal('reviewModal');
      showModal('previewModal');
    } catch(e){
      alert('Failed to open preview: '+(e&&e.message?e.message:e));
    }
  });

  $('#btnBackToReview').on('click', function(){ 
    hideModal('previewModal'); 
    showModal('reviewModal'); 
  });

  // -------------------------------------------------------
  // CONFIRM → FILL FORM
  // -------------------------------------------------------
  $('#btnConfirmFillForm').on('click', function(){
    if(!reviewedData) return;
    const d = reviewedData;

    const payload = {
      reference_no: d.reference_no || d.order_no || '',
      reference_no_field: d.reference_no || d.order_no || '',
      vendor_id: d.vendor_id || '',
      customer_id: d.customer_id || '',
      invoice_date: d.invoice_date || '',
      due_date: d.due_date || '',
      order_no: d.order_no || '',
      supplier_invoice_no: d.supplier_invoice_no || '',
      vendor_text: d.vendor_text || '',
      customer_text: d.customer_text || '',
      vendor_vat: d.vendor_vat || '',
      currency: d.currency || 'SAR',
      document_id: (currentOcrRes && currentOcrRes.document_id) ? currentOcrRes.document_id : '',
      items_json: JSON.stringify(d.items || [])
    };

    $('#btnConfirmFillForm').prop('disabled', true).text('Saving...');

    $.ajax({
      url: '<?= site_url("save-purchase-ocr") ?>',
      type: 'POST',
      dataType: 'json',
      data: payload,
     success: function(res){
    $('#btnConfirmFillForm').prop('disabled', false).text('Confirm & Fill Form');
    if(res.status === 'success'){
      hideModal('previewModal');
      if(res.redirect_url){
        window.location.href = res.redirect_url;
      } else {
        alert('Purchase saved successfully. Reference: ' + (res.reference || res.purchase_id || 'N/A'));
        location.reload();
      }
    } else {
      alert('Save failed: ' + (res.message || 'Unknown error'));
    }
},
      error: function(xhr){
        $('#btnConfirmFillForm').prop('disabled', false).text('Confirm & Fill Form');
        alert('Server error while saving. HTTP: ' + xhr.status);
      }
    });
  });

});
</script>